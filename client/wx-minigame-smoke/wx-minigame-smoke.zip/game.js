// 《尘霄问道》服务器连通性测试小游戏
// 用途：验证 wss://game.ct256.cn/ws（WebSocket）与 /healthz（HTTP）
// 协议帧：[msgId 4字节大端][bodyLen 4字节大端][protobuf body]

const SOCKET_URL = 'wss://game.ct256.cn/ws';
const HEALTH_URL = 'https://game.ct256.cn/healthz';

// ---------- 简易屏幕日志（画到 canvas，同时在 Console 输出） ----------
const canvas = wx.createCanvas();
const ctx = canvas.getContext('2d');
const logs = [];
function log(msg) {
  console.log(msg);
  logs.push(String(msg));
  if (logs.length > 22) logs.shift();
  ctx.fillStyle = '#0a1628';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#e6e6e6';
  ctx.font = '13px sans-serif';
  logs.forEach((l, i) => ctx.fillText(l, 8, 18 + i * 17));
}

// ---------- 协议编码 ----------
function encode(msgId, body) {
  const b = body || new ArrayBuffer(0);
  const buf = new ArrayBuffer(8 + b.byteLength);
  const dv = new DataView(buf);
  dv.setUint32(0, msgId);        // 大端
  dv.setUint32(4, b.byteLength); // 大端
  new Uint8Array(buf, 8).set(new Uint8Array(b));
  return buf;
}

// 字节数组转可读 ASCII（非打印字符显示为 .，便于看到 token 等字符串）
function bytesToAscii(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) {
    const c = bytes[i];
    s += (c >= 32 && c < 127) ? String.fromCharCode(c) : '.';
  }
  return s;
}

// ---------- 1. HTTP 健康检查 ----------
log('1) 健康检查 ' + HEALTH_URL);
wx.request({
  url: HEALTH_URL,
  success: (res) => log('   ✅ healthz: HTTP ' + res.statusCode + ' 数据=' + res.data),
  fail: (e) => log('   ❌ healthz 失败: ' + JSON.stringify(e)),
});

// ---------- 2. WebSocket 连接 ----------
log('2) 连接 ' + SOCKET_URL);
wx.connectSocket({ url: SOCKET_URL });

wx.onSocketOpen(() => {
  log('   ✅ 连接成功');
  // 发送 C2SLogin（msgId=1000，空 body 合法）
  wx.sendSocketMessage({ data: encode(1000) });
  log('   → 已发送 C2SLogin (msgId=1000)');
});

wx.onSocketMessage((res) => {
  const buf = res.data;              // ArrayBuffer
  const dv = new DataView(buf);
  const msgId = dv.getUint32(0);
  const len = dv.getUint32(4);
  const body = new Uint8Array(buf, 8, len);
  log('   ← 收到 msgId=' + msgId + ' len=' + len);
  log('     body(ascii): ' + bytesToAscii(body));

  // 收到 S2CLogin(1001) 后，再发一条「离线收益查询」演示多消息
  if (msgId === 1001) {
    setTimeout(() => {
      wx.sendSocketMessage({ data: encode(2000) });
      log('   → 已发送 C2SOfflineRewardQuery (msgId=2000)');
    }, 300);
  }
});

wx.onSocketError((e) => log('   ❌ Socket 错误: ' + JSON.stringify(e)));
wx.onSocketClose(() => log('   连接已关闭'));
